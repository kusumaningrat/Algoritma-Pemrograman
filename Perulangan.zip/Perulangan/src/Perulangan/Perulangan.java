package Perulangan;

import java.util.Scanner;

public class Perulangan {
    public static void main(String[] args) {

        // Looping atau Perulangan => suatu kondisi dimana blok program akan dieksekusi secara berulang-ulang
        // 1. Counted Loop => Perulangan yang jumlah pengulangannya terhitung atau tertentu (For dan For Each)
        // 2. Uncounted Loop => Perulangan yang jumlah pengulangannya tidak terhitung atau tidak tertentu (While dan Do/While)
        // 3. Infinite Loop => Perualangan yang tidak terbatas

//        System.out.println("Programming Community");
//        System.out.println("Programming Community");
//        System.out.println("Programming Community");
//        System.out.println("Programming Community");
//        System.out.println("Programming Community");

        // For
//        for (int i = 1; i <= 10; i++){
//            System.out.println("Programming Community");
//        }

        // For untuk mencetak angka (1,3,5,7..19)
//          for(int i = 1; i < 20; i+= 2){
//              System.out.print(i);
//          }


//         While
//        int i = 10;
//        while(i >= 1){
//            i = i + 1;
//            System.out.println("Programming Community");
//        }

        Scanner input = new Scanner(System.in);
        boolean running = true;
        String nama,alamat,jawab;

        while (running){
            System.out.print("Masukan Nama: ");
            nama = input.nextLine();
            System.out.print("Alamat: ");
            alamat = input.nextLine();

            System.out.println("=====OUTPUT======");
            System.out.println("Nama anda: " + nama);
            System.out.println("Alamat: " + alamat);
            System.out.println("=================");

            System.out.print("Input lagi (y/n)");
            jawab = input.nextLine();

            if(jawab.equalsIgnoreCase("n")){
                running = false;
            }
        }

        // Do While
//        int angka = 10;
//
//        do {
//            System.out.println(angka);
//        }while (angka > 5);

        // Nested Loop

//        for(int x = 1; x <= 5; x++){
//            for(int y = 1; y <= 3; y++){
//                System.out.printf("Perulangan ke-[x=%d, y=%d] %n", x,y);
//            }
//        }

//        for(int i = 0; i < 7; i++){
//            for(int j = 0; j < 7; j++){
//                System.out.print(" * ");
//                if(i == j){
//                    break;
//                }else if( (i + j) == 6){
//                    break;
//                }
//            }
//            System.out.println("\n");
//        }

//        for (int i = 5; i >= 1; i--){
//            for (int j = i; j <= 5; j++ ){
//                System.out.print(" * ");
//            }
//            System.out.println("");
//        }
//
//        for(int i = 4; i >= 1 ; i--){
//            for(int j = 1; j <= i; j++){
//                System.out.print(" * ");
//            }
//            System.out.println(" ");
//        }for (int i = 5; i >= 1; i--){
//            for (int j = i; j <= 5; j++ ){
//                System.out.print(" * ");
//            }
//            System.out.println("");
//        }
//
//        for(int i = 4; i >= 1 ; i--){
//            for(int j = 1; j <= i; j++){
//                System.out.print(" * ");
//            }
//            System.out.println(" ");
//        }

        // For Loop With Label
//        outter:
//        for (int i = 1; i < 10;i++){
//            System.out.println("Programming Community");
//                if(i == 6){
//                    break outter;
//                }
//        }

//        infinite loop
//        for (int i = 1; i <= 10; i--){
//            System.out.println(i);
//        }

    }
}
